# Oasis Resort roadmap

- [x] Foundation: design tokens, UI components, motion wrappers, public layout, all placeholder routes, 404/error, staff/admin portal layout
- [ ] Booking system + database (waiting for the user's go-ahead; also needs nightly prices and Easypaisa/bank account details)
- [ ] Phase 2: full staff/admin portals, reviews
