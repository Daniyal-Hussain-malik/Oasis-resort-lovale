# Oasis Resort Skardu — Phase 1: Public site + direct booking

## What you get in this phase
- **Public website** (/): Home, Rooms (Deluxe, Executive, Premium with detail pages), Dining, Gallery, About, Contact (map, WhatsApp, phone, email), FAQs, Policies. Your uploaded photos are used throughout.
- **Availability search and booking**: pick dates and guests, see which room types are free and the total in PKR, then book.
- **Payment**: the guest chooses Easypaisa or bank transfer, sees your account details, and uploads proof. The booking moves to "payment under review". A room stays held for a time you set (starts at 12 hours). After that the booking expires and the room is released.
- **Guest portal** (/account): sign up or log in, view bookings and statuses, upload payment proof, edit profile.
- **Minimal staff tool**: so bookings can actually be confirmed in Phase 1, one simple screen at /staff lists bookings under review, opens the proof through a private link, and lets staff approve or reject. Every approval is recorded in the audit log. The full staff and admin portals come in Phase 2.

## Content control
All text, photos, prices, room counts, policies, FAQs, contact details, payment account details and the hold time are stored in the database, not in the code. The Phase 2 admin portal will edit them. Starting data:
- Deluxe: 9 rooms, Executive: 6, Premium: 6. **Nightly prices are still needed** (placeholders until you send them).
- WhatsApp/phone: 0344-5537788, 0355-4114567. Email: oasisresort@gmail.com. Address: Cold desert, Katpana, Skardu 16100. The map uses a search for "Oasis Resort Katpana Skardu".
- Easypaisa and bank account details: placeholders until you send them.

## Design
Colours: sand background, navy text and night sections, glacier-blue details, apricot buttons. Cormorant Garamond for headings and Karla for body text. Large photos, plenty of space, calm fade and slide effects as you scroll (switched off for visitors who prefer reduced motion, and never on booking steps). Built mobile-first, from 320px phones up.

## Technical details
- Lovable Cloud: email/password and Google sign-in, a `profiles` table, and a separate `user_roles` table (guest, receptionist, manager, admin) with a `has_role()` function used in RLS policies.
- Tables: site_content (key/value, JSON), room_types, rooms, bookings, booking_rooms, payments, payment_methods, settings, faqs, policies, audit_log, reviews (table only for now).
- Booking status enum with all 8 statuses. `create_booking` is a SECURITY DEFINER function: it locks the rooms of that type (FOR UPDATE), checks for overlapping bookings that are not cancelled or expired, assigns rooms and inserts everything in one transaction. A daterange exclusion constraint on booking_rooms backs it up so a double booking is impossible.
- Expiry runs on a pg_cron job that marks unpaid holds as expired.
- Payment methods are a registry, so an online Easypaisa gateway can be added later as another provider. Proofs and IDs go in a private storage bucket and are viewed only through signed links for staff.
- Audit triggers on staff writes and payment approvals.
- i18n: all UI text in `src/i18n/en.json` behind a `t()` helper. Helpers for PKR formatting ("PKR 25,000") and Asia/Karachi dates ("19 Oct 2026").
- Photos are uploaded as CDN assets and used as the starting gallery content.

## Phase 2 (later)
Full staff portal (check-in/out, room assignment, enquiries, daily reports), manager tools (rates, promotions, refunds, review moderation), and the admin portal (content editor, staff accounts, settings, revenue, audit log viewer), plus reviews.
