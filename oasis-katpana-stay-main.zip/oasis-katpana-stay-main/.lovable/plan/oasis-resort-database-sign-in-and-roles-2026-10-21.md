# Oasis Resort: database, sign-in and roles

No public pages or booking screens are built in this step. Only the backend, plus the bare sign-in screens needed to test it.

## 1. Sign-in
- Email and password sign-up and login. Email must be verified before first login.
- Forgot password: sends an email link that opens a reset page.
- Google sign-in.
- Mobile number + one-time code: **needs an SMS provider account (e.g. Twilio) with your own keys.** I'll add the code path now, and it turns on once you give me the keys.
- No public staff sign-up. Every new account is a guest. Only an admin can give someone a staff role, through a protected server action.
- Admins and managers must set up an authenticator app (two-factor). Their staff and admin data is locked by the database until they complete the two-factor step, so it can't be reached just by hiding buttons.
- Staff sessions sign out after 30 minutes with no activity. A timer in the portal does this, and the server also rejects staff requests once the last activity is over 30 minutes old.
- Deactivating staff: an admin sets the account to inactive. This removes their sessions at once, and the database denies inactive accounts.

## 2. Roles
- `user_roles(user_id, role)`. The roles are guest, receptionist, manager and admin, and roles are never stored on the profile.
- `has_role(uid, role)`, `is_staff(uid)` (any active staff role) and `is_mgr(uid)` (manager or admin, active, two-factor done) run with elevated rights, and every rule below uses them.
- Shorthand used below: **Staff** = is_staff, **Mgr** = manager/admin with two-factor, **Admin** = admin with two-factor, **Own** = `user_id = auth.uid()`.

## 3. Tables and access rules

| Table | Key columns | Read | Write |
|---|---|---|---|
| profiles | user_id, full_name, phone, country, city, preferences jsonb, marketing_consent, is_active | Own, Staff | Own (not is_active); Admin |
| user_roles | user_id, role | Own, Admin | Admin only (via server action) |
| guest_identity | user_id, id_type (cnic/passport), id_number_encrypted, id_number_masked, nationality | Own, Staff | Own insert/update; Staff update |
| room_types | slug, name, description, max_adults, max_children, size, bed, amenities, sort, active | Public (active) | Mgr |
| rooms | room_type_id, number, floor, status, active | Staff | Mgr |
| rate_plans | room_type_id, name, base_price, meal_plan, refundable, active | Public | Mgr |
| seasons | name, start_date, end_date, multiplier | Public | Mgr |
| rates | rate_plan_id, season_id, price | Public | Mgr |
| date_overrides | room_type_id, date, price, closed, min_stay | Public | Mgr |
| taxes | name, percent, inclusive, active | Public | Admin |
| policies | slug, title, body | Public | Admin |
| bookings | reference, user_id, check_in, check_out, adults, children, status (8 statuses), totals, hold_expires_at, guest contact | Own, Staff | Created only via a protected booking function (next step); Staff update |
| booking_rooms | booking_id, room_id, stay daterange, active, **no-overlap rule** | Own (via booking), Staff | Booking function; Staff |
| addons | name, price, unit, active | Public | Mgr |
| booking_addons | booking_id, addon_id, qty, price | Own, Staff | Staff |
| payments | booking_id, user_id, method, amount, reference, proof_path, status, reviewed_by | Own, Staff | Guest submits via function; Staff approve/reject |
| refunds | payment_id, amount, reason, status, approved_by | Own, Staff | Mgr (up to limit in settings), Admin above it |
| invoices | booking_id, number, totals, issued_at | Own, Staff | Staff |
| folio_charges | booking_id, description, amount, posted_by | Own, Staff | Staff |
| reviews | booking_id (unique), user_id, rating, title, body, status | Public (published), Own, Staff | Own insert only if booking is checked_out; Mgr moderate |
| review_photos | review_id, path | Same as review | Own (pending review) |
| promo_codes | code, percent/amount, valid dates, usage limit | Mgr | Mgr |
| offers | title, body, image, dates, active | Public (active) | Mgr |
| pages, page_sections | slug, title, seo; page_id, type, content jsonb, sort | Public (published) | Admin |
| blog_posts, blog_categories, tags | title, slug, body, cover, status, published_at | Public (published) | Admin |
| gallery_albums, media | title; path, alt, album_id | Public | Admin |
| faqs, facilities, experiences, activities | title/question, body, image, sort, active | Public (active) | Admin |
| enquiries | name, email, phone, message, status | Staff | Anyone inserts (validated, rate-limited); Staff update |
| newsletter_subscribers | email, consent_at | Admin | Anyone inserts |
| notification_log | channel, to, template, status | Staff | Server only |
| audit_log | actor_id, action, table_name, record_id, before, after, ip, created_at | Admin | Trigger only, never edited |
| settings | key, value jsonb (payment hold hours, refund limit, contact, payment accounts) | Public keys only; Admin all | Admin |

Data that changes over time (dates, totals) is checked by database rules, not just on screen.

## 4. File storage
- `website` (public): website images. Only admins can upload.
- `payment-proofs` and `guest-ids` (private): guests upload into their own folder, and only the owning guest or staff can read. Files open through links that expire after 10 minutes. JPG, PNG and PDF only, max 5 MB.

## 5. Audit log
A trigger on every table above records every staff insert, update and delete: who, action, table, record, before and after values, and time. The IP address comes from the request headers.

## 6. Test accounts
One account per role, already confirmed:
- admin@oasis.test
- manager@oasis.test
- receptionist@oasis.test
- guest@oasis.test

Each gets a strong random password, which I'll show you once in chat. Admin and manager will be asked to set up an authenticator app on first login. These are for testing only; delete them before launch.

## Technical details
- The ID number is encrypted with pgcrypto `pgp_sym_encrypt`, using a key stored as a server secret. It is decrypted only inside a staff-only server function. The masked copy (35202-*****-1) is computed when the record is saved.
- Two-factor rule in policies: `(auth.jwt()->>'aal') = 'aal2'`. Staff access also requires the `profiles.is_active` flag.
- Session end on deactivation: `auth.admin.signOut` plus ban, called from an admin-checked server function.
- Idle timeout: `staff_sessions.last_seen` is updated by a heartbeat, and protected staff server functions reject sessions idle for more than 30 minutes.
- Test users are created through the admin user API in a one-off script, never from the app.

## Before I start
1. Do you want phone OTP now (I'll ask for the SMS provider keys) or later?
2. Is a 6-digit authenticator-app code acceptable for two-factor (Google Authenticator or Authy)?
