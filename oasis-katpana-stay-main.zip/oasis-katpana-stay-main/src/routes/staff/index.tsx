import { createFileRoute } from "@tanstack/react-router";
import { PortalPlaceholder } from "@/components/portal/PortalShell";

export const Route = createFileRoute("/staff/")({
  component: PortalPlaceholder,
});
