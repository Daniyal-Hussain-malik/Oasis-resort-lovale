import { createFileRoute, Outlet } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";

export const Route = createFileRoute("/staff")({
  head: () => ({ meta: [{ title: "Staff portal — Oasis Resort" }, { name: "robots", content: "noindex" }] }),
  component: () => (
    <PortalShell kind="staff">
      <Outlet />
    </PortalShell>
  ),
});
