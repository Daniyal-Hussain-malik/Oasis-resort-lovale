import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { t } from "@/i18n";
import { images } from "@/content/site";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

function BrandedMessage({ code, title, body, action }: { code?: string; title: string; body: string; action?: ReactNode }) {
  return (
    <div className="relative isolate flex min-h-screen items-center justify-center overflow-hidden bg-navy px-5 text-navy-foreground">
      <img src={images.night} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover opacity-40" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-navy via-navy/70 to-navy/40" />
      <div className="max-w-lg text-center">
        {code && <p className="font-serif text-8xl text-apricot">{code}</p>}
        <h1 className="mt-2 text-4xl md:text-5xl">{title}</h1>
        <p className="mt-4 text-lg text-navy-foreground/85">{body}</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          {action}
          <Button asChild variant="light" size="lg"><Link to="/">{t("common.backHome")}</Link></Button>
          <Button asChild variant="primary" size="lg"><Link to="/book">{t("nav.bookNow")}</Link></Button>
        </div>
      </div>
    </div>
  );
}

function NotFoundComponent() {
  return <BrandedMessage code="404" title={t("errors.notFoundTitle")} body={t("errors.notFoundBody")} />;
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return (
    <BrandedMessage
      title={t("errors.errorTitle")}
      body={t("errors.errorBody")}
      action={<Button variant="light" size="lg" onClick={() => { router.invalidate(); reset(); }}>{t("errors.tryAgain")}</Button>}
    />
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: "Oasis Resort Skardu — Cottages in the Katpana Cold Desert" },
      { name: "description", content: "Book direct at Oasis Resort, Katpana, Skardu: glass-front cottages facing the Karakoram, starry desert nights and warm Balti hospitality." },
      { property: "og:title", content: "Oasis Resort Skardu" },
      { property: "og:description", content: "Glass-front cottages in the Katpana cold desert, Skardu. Book direct for the best rate." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "theme-color", content: "#1c2440" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Karla:wght@400;500;600;700&display=swap" },
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
      <Toaster position="top-center" richColors />
    </QueryClientProvider>
  );
}
