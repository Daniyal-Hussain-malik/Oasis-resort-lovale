import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/facilities")({
  head: () => ({
    meta: [
      { title: "Facilities — Oasis Resort Skardu" },
      { name: "description", content: "Heating, hot water, Wi-Fi, dining, bonfire and everything for a comfortable stay." },
      { property: "og:title", content: "Facilities — Oasis Resort Skardu" },
      { property: "og:description", content: "Heating, hot water, Wi-Fi, dining, bonfire and everything for a comfortable stay." },
    ],
  }),
  component: FacilitiesPage,
});

function FacilitiesPage() {
  return <PlaceholderPage title="Facilities" subtitle="Heating, hot water, Wi-Fi, dining, bonfire and everything for a comfortable stay." image={images.executive} />;
}
