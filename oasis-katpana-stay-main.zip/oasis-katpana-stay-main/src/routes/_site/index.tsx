import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import type { DateRange } from "react-day-picker";
import { ArrowRight, Check, Mountain, Plane, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { DateRangePicker } from "@/components/booking/DateRangePicker";
import { GuestCounter, type Guests } from "@/components/booking/GuestCounter";
import { CountUp, FadeInOnScroll, HoverLift, SlideUp, StaggerChildren, StaggerItem } from "@/components/motion";
import { GalleryGrid } from "@/components/site/Lightbox";
import { gallery, images, roomTypes } from "@/content/site";
import { t } from "@/i18n";

export const Route = createFileRoute("/_site/")({
  head: () => ({
    meta: [
      { title: "Oasis Resort Skardu — Book Direct in the Katpana Cold Desert" },
      { name: "description", content: "Glass-front cottages facing the Karakoram in Katpana, Skardu. Book direct for the best rate and pay with Easypaisa or bank transfer." },
      { property: "og:title", content: "Oasis Resort Skardu — Where the desert meets the Karakoram" },
      { property: "og:description", content: "Glass-front cottages, starlit desert nights and warm Balti hospitality. Book direct." },
    ],
  }),
  component: Home,
});

function SearchBar() {
  const [range, setRange] = useState<DateRange | undefined>();
  const [guests, setGuests] = useState<Guests>({ adults: 2, children: 0 });
  const navigate = useNavigate();
  return (
    <Card className="grid gap-3 rounded-3xl border-0 bg-card/95 p-3 text-foreground shadow-lift backdrop-blur sm:grid-cols-2 lg:grid-cols-[1.6fr_1fr_auto]">
      <DateRangePicker value={range} onChange={setRange} className="sm:col-span-2 lg:col-span-1" />
      <GuestCounter value={guests} onChange={setGuests} />
      <Button variant="primary" size="lg" className="sm:col-span-1 lg:col-span-1" onClick={() => navigate({ to: "/book" })}>
        Check availability
      </Button>
    </Card>
  );
}

function Home() {
  return (
    <>
      {/* Hero */}
      <section className="relative isolate flex min-h-[100svh] items-end overflow-hidden bg-navy text-navy-foreground">
        <img src={images.hero} alt="Oasis Resort cottages and teepee under a starry sky in Katpana" className="absolute inset-0 -z-10 h-full w-full object-cover" fetchPriority="high" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-t from-navy via-navy/40 to-navy/10" />
        <div className="container-site pb-10 pt-32 md:pb-16">
          <SlideUp>
            <p className="eyebrow text-apricot">Katpana Cold Desert · Skardu</p>
            <h1 className="mt-4 max-w-4xl text-5xl sm:text-6xl lg:text-7xl 2xl:text-8xl">Where the desert meets the Karakoram</h1>
            <p className="mt-5 max-w-2xl text-lg text-navy-foreground/85 md:text-xl">
              Glass-fronted cottages on the sands of Katpana, with snow peaks at your window and the clearest night sky in Pakistan.
            </p>
          </SlideUp>
          <SlideUp delay={0.15} className="mt-8 max-w-4xl">
            <SearchBar />
          </SlideUp>
        </div>
      </section>

      {/* Intro */}
      <section className="container-site section-y grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
        <SlideUp>
          <p className="eyebrow text-glacier">Welcome</p>
          <h2 className="mt-3 text-4xl md:text-5xl">A quiet oasis at 2,300 metres</h2>
          <p className="mt-5 text-lg text-muted-foreground">
            Oasis Resort sits in the cold desert of Katpana, minutes from Skardu city and the airport. Wake to sunrise over the mountains, explore Shangrila, Kachura and Deosai by day, and return to a bonfire under a sky full of stars.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-4 border-t border-border pt-8">
            <div><p className="font-serif text-4xl text-navy"><CountUp to={21} /></p><p className="text-sm text-muted-foreground">Rooms & cottages</p></div>
            <div><p className="font-serif text-4xl text-navy"><CountUp to={10} suffix=" min" /></p><p className="text-sm text-muted-foreground">From the airport</p></div>
            <div><p className="font-serif text-4xl text-navy"><CountUp to={2300} suffix=" m" /></p><p className="text-sm text-muted-foreground">Altitude</p></div>
          </div>
        </SlideUp>
        <FadeInOnScroll>
          <img src={images.snow} alt="Red-roofed cottages in winter snow with mountains behind" loading="lazy" className="aspect-[4/3] w-full rounded-3xl object-cover shadow-lift" />
        </FadeInOnScroll>
      </section>

      {/* Rooms */}
      <section className="bg-card section-y">
        <div className="container-site">
          <SlideUp className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="eyebrow text-glacier">Stay</p>
              <h2 className="mt-3 text-4xl md:text-5xl">Rooms with a view of everything</h2>
            </div>
            <Button asChild variant="outline"><Link to="/stay">All rooms <ArrowRight /></Link></Button>
          </SlideUp>
          <StaggerChildren className="mt-10 grid gap-6 md:grid-cols-3">
            {roomTypes.map((r) => (
              <StaggerItem key={r.slug}>
                <HoverLift>
                  <Link to="/stay/$slug" params={{ slug: r.slug }} className="group block overflow-hidden rounded-3xl bg-background shadow-soft">
                    <div className="overflow-hidden"><img src={r.image} alt={r.name} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105" /></div>
                    <div className="p-6">
                      <h3 className="text-2xl">{r.name}</h3>
                      <p className="mt-1 text-muted-foreground">{r.tagline}</p>
                      <p className="mt-4 inline-flex items-center gap-1 font-semibold text-navy">View room <ArrowRight className="h-4 w-4" /></p>
                    </div>
                  </Link>
                </HoverLift>
              </StaggerItem>
            ))}
          </StaggerChildren>
        </div>
      </section>

      {/* Night */}
      <section className="relative isolate overflow-hidden bg-navy text-navy-foreground">
        <img src={images.night} alt="" loading="lazy" className="absolute inset-0 -z-10 h-full w-full object-cover opacity-60" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-navy via-navy/70 to-transparent" />
        <div className="container-site py-24 md:py-36">
          <SlideUp className="max-w-xl">
            <p className="eyebrow text-apricot">Experiences</p>
            <h2 className="mt-3 text-4xl md:text-5xl">Nights under a sky full of stars</h2>
            <p className="mt-5 text-lg text-navy-foreground/85">Far from city lights, Katpana's desert turns into an open-air observatory. Dinner by the bonfire, tea in the teepee, and the Milky Way overhead.</p>
            <Button asChild variant="light" className="mt-8"><Link to="/experiences">Explore experiences <ArrowRight /></Link></Button>
          </SlideUp>
        </div>
      </section>

      {/* Book direct */}
      <section className="container-site section-y">
        <SlideUp className="text-center">
          <p className="eyebrow text-glacier">Why book direct</p>
          <h2 className="mt-3 text-4xl md:text-5xl">Book direct, get more</h2>
        </SlideUp>
        <StaggerChildren className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            { icon: Sparkles, title: "Best rate guaranteed", body: "No booking-site fees. The price you see is the price you pay." },
            { icon: Check, title: "Easy local payment", body: "Pay with Easypaisa or bank transfer and upload your receipt." },
            { icon: Plane, title: "Talk to real people", body: "Message us on WhatsApp for airport pick-up, tours and special requests." },
          ].map(({ icon: Icon, title, body }) => (
            <StaggerItem key={title}>
              <HoverLift className="h-full">
                <Card className="h-full rounded-3xl border-border p-8 shadow-soft">
                  <span className="grid h-12 w-12 place-items-center rounded-full bg-apricot/20 text-apricot-foreground"><Icon className="h-5 w-5" /></span>
                  <h3 className="mt-5 text-2xl">{title}</h3>
                  <p className="mt-2 text-muted-foreground">{body}</p>
                </Card>
              </HoverLift>
            </StaggerItem>
          ))}
        </StaggerChildren>
      </section>

      {/* Gallery */}
      <section className="bg-card section-y">
        <div className="container-site">
          <SlideUp className="mb-10 flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="eyebrow text-glacier">Gallery</p>
              <h2 className="mt-3 text-4xl md:text-5xl">Seasons at Oasis</h2>
            </div>
            <Button asChild variant="outline"><Link to="/gallery">Full gallery <ArrowRight /></Link></Button>
          </SlideUp>
          <GalleryGrid images={gallery.slice(0, 5)} />
        </div>
      </section>

      {/* CTA */}
      <section className="container-site section-y text-center">
        <SlideUp>
          <Mountain className="mx-auto h-10 w-10 text-glacier" />
          <h2 className="mx-auto mt-4 max-w-2xl text-4xl md:text-5xl">Your window on the Karakoram is waiting</h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button asChild variant="primary" size="lg"><Link to="/book">{t("nav.bookNow")}</Link></Button>
            <Button asChild variant="outline" size="lg"><Link to="/contact">{t("nav.contact")}</Link></Button>
          </div>
        </SlideUp>
      </section>
    </>
  );
}
