import { createFileRoute, notFound } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { roomTypes } from "@/content/site";

export const Route = createFileRoute("/_site/stay/$slug")({
  loader: ({ params }) => {
    const room = roomTypes.find((r) => r.slug === params.slug);
    if (!room) throw notFound();
    return room;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.name ?? "Room"} — Oasis Resort Skardu` },
      { name: "description", content: loaderData?.tagline ?? "Room details at Oasis Resort Skardu." },
      { property: "og:title", content: `${loaderData?.name ?? "Room"} — Oasis Resort Skardu` },
      { property: "og:description", content: loaderData?.tagline ?? "Room details at Oasis Resort Skardu." },
    ],
  }),
  component: RoomPage,
  notFoundComponent: () => <PlaceholderPage title="Room not found" crumbs={[{ label: "Stay", to: "/stay" }, { label: "Not found" }]} />,
  errorComponent: () => <PlaceholderPage title="Room unavailable" crumbs={[{ label: "Stay", to: "/stay" }, { label: "Error" }]} />,
});

function RoomPage() {
  const room = Route.useLoaderData();
  return <PlaceholderPage title={room.name} subtitle={room.tagline} image={room.image} crumbs={[{ label: "Stay", to: "/stay" }, { label: room.name }]} />;
}
