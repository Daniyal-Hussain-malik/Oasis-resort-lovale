import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { HoverLift, StaggerChildren, StaggerItem } from "@/components/motion";
import { PageHero } from "@/components/site/PageHero";
import { images, roomTypes } from "@/content/site";

export const Route = createFileRoute("/_site/stay/")({
  head: () => ({
    meta: [
      { title: "Rooms & Cottages — Oasis Resort Skardu" },
      { name: "description", content: "Deluxe rooms, Executive rooms and Premium glass-front cottages in Katpana, Skardu." },
      { property: "og:title", content: "Rooms & Cottages — Oasis Resort Skardu" },
      { property: "og:description", content: "Deluxe, Executive and Premium stays facing the Karakoram." },
    ],
  }),
  component: StayPage,
});

function StayPage() {
  return (
    <>
      <PageHero title="Stay" subtitle="Three ways to wake up facing the mountains." image={images.deluxe} crumbs={[{ label: "Stay" }]} />
      <section className="container-site section-y">
        <StaggerChildren className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {roomTypes.map((r) => (
            <StaggerItem key={r.slug}>
              <HoverLift>
                <Link to="/stay/$slug" params={{ slug: r.slug }} className="group block overflow-hidden rounded-3xl bg-card shadow-soft">
                  <div className="overflow-hidden"><img src={r.image} alt={r.name} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105" /></div>
                  <div className="p-6">
                    <h2 className="text-3xl">{r.name}</h2>
                    <p className="mt-1 text-muted-foreground">{r.tagline} · {r.count} rooms</p>
                    <p className="mt-4 inline-flex items-center gap-1 font-semibold text-navy">View details <ArrowRight className="h-4 w-4" /></p>
                  </div>
                </Link>
              </HoverLift>
            </StaggerItem>
          ))}
        </StaggerChildren>
      </section>
    </>
  );
}
