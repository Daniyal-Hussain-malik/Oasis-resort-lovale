import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy policy — Oasis Resort Skardu" },
      { name: "description", content: "How we collect, use and protect your information." },
      { property: "og:title", content: "Privacy policy — Oasis Resort Skardu" },
      { property: "og:description", content: "How we collect, use and protect your information." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return <PlaceholderPage title="Privacy policy" subtitle="How we collect, use and protect your information." image={images.hero} />;
}
