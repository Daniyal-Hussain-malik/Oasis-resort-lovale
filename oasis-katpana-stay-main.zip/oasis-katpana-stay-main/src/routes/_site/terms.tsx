import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/terms")({
  head: () => ({
    meta: [
      { title: "Terms & conditions — Oasis Resort Skardu" },
      { name: "description", content: "The terms that apply when you book with us." },
      { property: "og:title", content: "Terms & conditions — Oasis Resort Skardu" },
      { property: "og:description", content: "The terms that apply when you book with us." },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return <PlaceholderPage title="Terms & conditions" subtitle="The terms that apply when you book with us." image={images.hero} />;
}
