import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { AuthCard, Field } from "@/components/site/AuthCard";

export const Route = createFileRoute("/_site/forgot-password")({
  head: () => ({
    meta: [
      { title: "Forgot password — Oasis Resort Skardu" },
      { name: "description", content: "We'll email you a link to reset it." },
      { property: "og:title", content: "Forgot password — Oasis Resort Skardu" },
      { property: "og:description", content: "We'll email you a link to reset it." },
    ],
  }),
  component: ForgotPasswordPage,
});

function ForgotPasswordPage() {
  return (
    <AuthCard title="Forgot password" subtitle="We'll email you a link to reset it.">
      <form className="grid gap-4" onSubmit={(e) => { e.preventDefault(); toast.info("Accounts are coming in the next step."); }}>
        <Field id="email" label="Email" type="email" autoComplete="email" />
        <Button type="submit" variant="primary" size="lg">Send reset link</Button>
      </form>
      <div className="mt-4 flex flex-wrap justify-between gap-2 text-sm">
        <Link to="/login" className="inline-flex min-h-11 items-center underline">Back to sign in</Link>
      </div>
    </AuthCard>
  );
}
