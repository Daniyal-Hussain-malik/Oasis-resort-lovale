import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/about")({
  head: () => ({
    meta: [
      { title: "About Oasis Resort — Oasis Resort Skardu" },
      { name: "description", content: "A family-run retreat in the cold desert of Katpana, Skardu." },
      { property: "og:title", content: "About Oasis Resort — Oasis Resort Skardu" },
      { property: "og:description", content: "A family-run retreat in the cold desert of Katpana, Skardu." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return <PlaceholderPage title="About Oasis Resort" subtitle="A family-run retreat in the cold desert of Katpana, Skardu." image={images.snow} />;
}
