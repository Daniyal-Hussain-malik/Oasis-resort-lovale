import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";

const titleFrom = (slug: string) => slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

export const Route = createFileRoute("/_site/blog/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `${titleFrom(params.slug)} — Oasis Resort Journal` },
      { name: "description", content: "Travel notes from Oasis Resort, Skardu." },
      { property: "og:title", content: `${titleFrom(params.slug)} — Oasis Resort Journal` },
      { property: "og:description", content: "Travel notes from Oasis Resort, Skardu." },
      { property: "og:type", content: "article" },
    ],
  }),
  component: BlogPost,
});

function BlogPost() {
  const { slug } = Route.useParams();
  return <PlaceholderPage title={titleFrom(slug)} crumbs={[{ label: "Blog", to: "/blog" }, { label: titleFrom(slug) }]} />;
}
