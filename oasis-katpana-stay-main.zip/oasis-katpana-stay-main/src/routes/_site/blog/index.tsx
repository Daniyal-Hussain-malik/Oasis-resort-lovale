import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/blog/")({
  head: () => ({
    meta: [
      { title: "Journal — Oasis Resort Skardu" },
      { name: "description", content: "Travel notes and guides for Skardu and Gilgit-Baltistan." },
      { property: "og:title", content: "Journal — Oasis Resort Skardu" },
      { property: "og:description", content: "Travel notes and guides for Skardu and Gilgit-Baltistan." },
    ],
  }),
  component: BlogPage,
});

function BlogPage() {
  return <PlaceholderPage title="Journal" subtitle="Travel notes and guides for Skardu and Gilgit-Baltistan." image={images.hero} />;
}
