import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { AuthCard, Field } from "@/components/site/AuthCard";

export const Route = createFileRoute("/_site/login")({
  head: () => ({
    meta: [
      { title: "Login — Oasis Resort Skardu" },
      { name: "description", content: "Sign in to manage your bookings." },
      { property: "og:title", content: "Login — Oasis Resort Skardu" },
      { property: "og:description", content: "Sign in to manage your bookings." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  return (
    <AuthCard title="Login" subtitle="Sign in to manage your bookings.">
      <form className="grid gap-4" onSubmit={(e) => { e.preventDefault(); toast.info("Accounts are coming in the next step."); }}>
        <Field id="email" label="Email" type="email" autoComplete="email" />
        <Field id="password" label="Password" type="password" autoComplete="current-password" />
        <Button type="submit" variant="primary" size="lg">Sign in</Button>
      </form>
      <div className="mt-4 flex flex-wrap justify-between gap-2 text-sm">
        <Link to="/register" className="inline-flex min-h-11 items-center underline">Create an account</Link>
        <Link to="/forgot-password" className="inline-flex min-h-11 items-center underline">Forgot password?</Link>
      </div>
    </AuthCard>
  );
}
