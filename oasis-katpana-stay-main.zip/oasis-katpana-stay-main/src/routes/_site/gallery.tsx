import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/site/PageHero";
import { GalleryGrid } from "@/components/site/Lightbox";
import { gallery, images } from "@/content/site";

export const Route = createFileRoute("/_site/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Oasis Resort Skardu" },
      { name: "description", content: "Photos of our cottages, rooms, dining and starry desert nights in Katpana." },
      { property: "og:title", content: "Gallery — Oasis Resort Skardu" },
      { property: "og:description", content: "Cottages, rooms and starry desert nights in Katpana, Skardu." },
    ],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  return (
    <>
      <PageHero title="Gallery" subtitle="Snow, sand and stars — Oasis through the seasons." image={images.night} crumbs={[{ label: "Gallery" }]} />
      <section className="container-site section-y"><GalleryGrid images={gallery} /></section>
    </>
  );
}
