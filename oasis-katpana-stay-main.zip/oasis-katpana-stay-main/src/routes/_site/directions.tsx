import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/directions")({
  head: () => ({
    meta: [
      { title: "Directions — Oasis Resort Skardu" },
      { name: "description", content: "Minutes from Skardu airport and city, in the Katpana cold desert." },
      { property: "og:title", content: "Directions — Oasis Resort Skardu" },
      { property: "og:description", content: "Minutes from Skardu airport and city, in the Katpana cold desert." },
    ],
  }),
  component: DirectionsPage,
});

function DirectionsPage() {
  return <PlaceholderPage title="Directions" subtitle="Minutes from Skardu airport and city, in the Katpana cold desert." image={images.hero} />;
}
