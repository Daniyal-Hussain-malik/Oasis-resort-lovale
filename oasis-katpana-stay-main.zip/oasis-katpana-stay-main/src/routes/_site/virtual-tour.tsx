import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/virtual-tour")({
  head: () => ({
    meta: [
      { title: "Virtual Tour — Oasis Resort Skardu" },
      { name: "description", content: "Walk through our cottages and grounds before you arrive." },
      { property: "og:title", content: "Virtual Tour — Oasis Resort Skardu" },
      { property: "og:description", content: "Walk through our cottages and grounds before you arrive." },
    ],
  }),
  component: VirtualTourPage,
});

function VirtualTourPage() {
  return <PlaceholderPage title="Virtual Tour" subtitle="Walk through our cottages and grounds before you arrive." image={images.snow} />;
}
