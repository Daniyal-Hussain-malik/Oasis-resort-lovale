import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/experiences")({
  head: () => ({
    meta: [
      { title: "Experiences — Oasis Resort Skardu" },
      { name: "description", content: "Starlit dinners, desert sunrises and Balti hospitality." },
      { property: "og:title", content: "Experiences — Oasis Resort Skardu" },
      { property: "og:description", content: "Starlit dinners, desert sunrises and Balti hospitality." },
    ],
  }),
  component: ExperiencesPage,
});

function ExperiencesPage() {
  return <PlaceholderPage title="Experiences" subtitle="Starlit dinners, desert sunrises and Balti hospitality." image={images.night} />;
}
