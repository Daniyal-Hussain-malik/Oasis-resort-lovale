import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { AuthCard, Field } from "@/components/site/AuthCard";

export const Route = createFileRoute("/_site/register")({
  head: () => ({
    meta: [
      { title: "Create account — Oasis Resort Skardu" },
      { name: "description", content: "Register to book faster and track your stays." },
      { property: "og:title", content: "Create account — Oasis Resort Skardu" },
      { property: "og:description", content: "Register to book faster and track your stays." },
    ],
  }),
  component: RegisterPage,
});

function RegisterPage() {
  return (
    <AuthCard title="Create account" subtitle="Register to book faster and track your stays.">
      <form className="grid gap-4" onSubmit={(e) => { e.preventDefault(); toast.info("Accounts are coming in the next step."); }}>
        <Field id="name" label="Full name" type="text" autoComplete="name" />
        <Field id="email" label="Email" type="email" autoComplete="email" />
        <Field id="phone" label="Phone" type="tel" autoComplete="tel" />
        <Field id="password" label="Password" type="password" autoComplete="new-password" />
        <Button type="submit" variant="primary" size="lg">Create account</Button>
      </form>
      <div className="mt-4 flex flex-wrap justify-between gap-2 text-sm">
        <Link to="/login" className="inline-flex min-h-11 items-center underline">Already have an account? Sign in</Link>
      </div>
    </AuthCard>
  );
}
