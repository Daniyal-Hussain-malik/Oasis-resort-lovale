import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/cancellation-policy")({
  head: () => ({
    meta: [
      { title: "Cancellation policy — Oasis Resort Skardu" },
      { name: "description", content: "What happens if your plans change." },
      { property: "og:title", content: "Cancellation policy — Oasis Resort Skardu" },
      { property: "og:description", content: "What happens if your plans change." },
    ],
  }),
  component: CancellationPolicyPage,
});

function CancellationPolicyPage() {
  return <PlaceholderPage title="Cancellation policy" subtitle="What happens if your plans change." image={images.hero} />;
}
