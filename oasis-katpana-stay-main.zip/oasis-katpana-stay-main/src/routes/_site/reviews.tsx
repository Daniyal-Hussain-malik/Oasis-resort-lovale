import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/reviews")({
  head: () => ({
    meta: [
      { title: "Guest reviews — Oasis Resort Skardu" },
      { name: "description", content: "Verified stays, honest words." },
      { property: "og:title", content: "Guest reviews — Oasis Resort Skardu" },
      { property: "og:description", content: "Verified stays, honest words." },
    ],
  }),
  component: ReviewsPage,
});

function ReviewsPage() {
  return <PlaceholderPage title="Guest reviews" subtitle="Verified stays, honest words." image={images.night} />;
}
