import { createFileRoute, Outlet, useLocation } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { CookieBanner, MobileBookBar, WhatsAppFab } from "@/components/site/Floating";
import { PageTransition } from "@/components/motion";

export const Route = createFileRoute("/_site")({
  component: SiteLayout,
});

function SiteLayout() {
  const { pathname } = useLocation();
  return (
    <div className="pb-safe-bar flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[60] focus:rounded focus:bg-card focus:p-3">Skip to content</a>
      <Header />
      <main id="main" className="flex-1">
        <PageTransition key={pathname}>
          <Outlet />
        </PageTransition>
      </main>
      <Footer />
      <WhatsAppFab />
      <MobileBookBar />
      <CookieBanner />
    </div>
  );
}
