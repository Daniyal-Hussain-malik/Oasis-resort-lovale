import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/offers")({
  head: () => ({
    meta: [
      { title: "Offers — Oasis Resort Skardu" },
      { name: "description", content: "Seasonal deals for guests who book direct." },
      { property: "og:title", content: "Offers — Oasis Resort Skardu" },
      { property: "og:description", content: "Seasonal deals for guests who book direct." },
    ],
  }),
  component: OffersPage,
});

function OffersPage() {
  return <PlaceholderPage title="Offers" subtitle="Seasonal deals for guests who book direct." image={images.snow} />;
}
