import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import type { DateRange } from "react-day-picker";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { DateRangePicker } from "@/components/booking/DateRangePicker";
import { GuestCounter, type Guests } from "@/components/booking/GuestCounter";
import { PageHero } from "@/components/site/PageHero";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/book")({
  head: () => ({
    meta: [
      { title: "Book Your Stay — Oasis Resort Skardu" },
      { name: "description", content: "Check availability and book direct at Oasis Resort, Katpana, Skardu." },
      { property: "og:title", content: "Book Your Stay — Oasis Resort Skardu" },
      { property: "og:description", content: "Check availability and book direct for the best rate." },
    ],
  }),
  component: BookPage,
});

// No animation on booking steps by design: keep this page fast.
function BookPage() {
  const [range, setRange] = useState<DateRange | undefined>();
  const [guests, setGuests] = useState<Guests>({ adults: 2, children: 0 });
  return (
    <>
      <PageHero title="Book your stay" subtitle="Choose your dates and guests." image={images.deluxe1} crumbs={[{ label: "Book" }]} />
      <section className="container-site section-y">
        <Card className="mx-auto grid max-w-3xl gap-4 rounded-3xl p-6 shadow-soft md:p-8">
          <DateRangePicker value={range} onChange={setRange} />
          <GuestCounter value={guests} onChange={setGuests} />
          <Button variant="primary" size="lg" onClick={() => toast.info("Live availability is coming in the next step.")}>Check availability</Button>
        </Card>
      </section>
    </>
  );
}
