import { createFileRoute } from "@tanstack/react-router";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { SlideUp } from "@/components/motion";
import { PageHero } from "@/components/site/PageHero";
import { images } from "@/content/site";

// Starter FAQs; these become admin-editable when the database is added.
const faqs = [
  { q: "How do I reach Oasis Resort?", a: "We are in Katpana, about 10 minutes from Skardu airport and city. We can arrange pick-up on request." },
  { q: "When is my booking confirmed?", a: "Your booking is confirmed once our team verifies your Easypaisa or bank payment." },
  { q: "What are check-in and check-out times?", a: "Check-in is from 2:00 PM and check-out is by 12:00 PM." },
  { q: "Is it cold at night?", a: "Yes. Katpana is a cold desert and nights can be chilly even in summer. All rooms have heating." },
];

export const Route = createFileRoute("/_site/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Oasis Resort Skardu" },
      { name: "description", content: "Answers about getting here, payments, check-in times and weather at Oasis Resort, Skardu." },
      { property: "og:title", content: "FAQ — Oasis Resort Skardu" },
      { property: "og:description", content: "Getting here, payments, check-in and weather." },
    ],
  }),
  component: FaqPage,
});

function FaqPage() {
  return (
    <>
      <PageHero title="Frequently asked questions" image={images.snow} crumbs={[{ label: "FAQ" }]} />
      <section className="container-site section-y">
        <SlideUp className="mx-auto max-w-3xl">
          <Accordion type="single" collapsible className="rounded-3xl bg-card px-6 shadow-soft">
            {faqs.map((f, i) => (
              <AccordionItem key={f.q} value={`f${i}`}>
                <AccordionTrigger className="min-h-14 text-left font-serif text-xl">{f.q}</AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </SlideUp>
      </section>
    </>
  );
}
