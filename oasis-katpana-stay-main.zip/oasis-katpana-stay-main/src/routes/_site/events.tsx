import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/events")({
  head: () => ({
    meta: [
      { title: "Events — Oasis Resort Skardu" },
      { name: "description", content: "Private dinners, celebrations and group retreats in the desert." },
      { property: "og:title", content: "Events — Oasis Resort Skardu" },
      { property: "og:description", content: "Private dinners, celebrations and group retreats in the desert." },
    ],
  }),
  component: EventsPage,
});

function EventsPage() {
  return <PlaceholderPage title="Events" subtitle="Private dinners, celebrations and group retreats in the desert." image={images.night} />;
}
