import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/activities")({
  head: () => ({
    meta: [
      { title: "Activities — Oasis Resort Skardu" },
      { name: "description", content: "Jeep safaris, Shangrila, Kachura lakes, Deosai and more around Skardu." },
      { property: "og:title", content: "Activities — Oasis Resort Skardu" },
      { property: "og:description", content: "Jeep safaris, Shangrila, Kachura lakes, Deosai and more around Skardu." },
    ],
  }),
  component: ActivitiesPage,
});

function ActivitiesPage() {
  return <PlaceholderPage title="Activities" subtitle="Jeep safaris, Shangrila, Kachura lakes, Deosai and more around Skardu." image={images.hero} />;
}
