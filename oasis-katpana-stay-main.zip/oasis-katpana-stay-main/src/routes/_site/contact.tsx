import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/contact")({
  head: () => ({
    meta: [
      { title: "Contact us — Oasis Resort Skardu" },
      { name: "description", content: "Call, WhatsApp or email us — we usually reply within the hour." },
      { property: "og:title", content: "Contact us — Oasis Resort Skardu" },
      { property: "og:description", content: "Call, WhatsApp or email us — we usually reply within the hour." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return <PlaceholderPage title="Contact us" subtitle="Call, WhatsApp or email us — we usually reply within the hour." image={images.night} />;
}
