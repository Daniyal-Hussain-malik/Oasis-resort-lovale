import { createFileRoute } from "@tanstack/react-router";
import { PlaceholderPage } from "@/components/site/PlaceholderPage";
import { images } from "@/content/site";

export const Route = createFileRoute("/_site/account")({
  head: () => ({
    meta: [
      { title: "My account — Oasis Resort Skardu" },
      { name: "description", content: "Your bookings, payments and profile." },
      { property: "og:title", content: "My account — Oasis Resort Skardu" },
      { property: "og:description", content: "Your bookings, payments and profile." },
    ],
  }),
  component: AccountPage,
});

function AccountPage() {
  return <PlaceholderPage title="My account" subtitle="Your bookings, payments and profile." image={images.snow} />;
}
