import { createFileRoute, Outlet } from "@tanstack/react-router";
import { PortalShell } from "@/components/portal/PortalShell";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin portal — Oasis Resort" }, { name: "robots", content: "noindex" }] }),
  component: () => (
    <PortalShell kind="admin">
      <Outlet />
    </PortalShell>
  ),
});
