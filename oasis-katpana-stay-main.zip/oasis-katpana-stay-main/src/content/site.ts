// Temporary starter content. When the database is added, these values move to the
// admin-editable content store and this file only provides fallbacks.
import hero from "@/assets/oasis-resort-skardu--13.jpg.asset.json";
import snow from "@/assets/657572402.jpg.asset.json";
import night from "@/assets/open-env-night.jpg.asset.json";
import breakfast from "@/assets/breakfast.jpg.asset.json";
import deluxe from "@/assets/deluxe-room.jpeg.asset.json";
import deluxe1 from "@/assets/deluxe-room1.jpeg.asset.json";
import deluxe2 from "@/assets/deluxe-room2.jpeg.asset.json";
import executive from "@/assets/executive-room.jpg.asset.json";

export const images = {
  hero: hero.url, snow: snow.url, night: night.url, breakfast: breakfast.url,
  deluxe: deluxe.url, deluxe1: deluxe1.url, deluxe2: deluxe2.url, executive: executive.url,
};

export const contact = {
  primaryPhone: "0344-5537788",
  primaryWhatsapp: "0344-5537788",
  phones: ["0344-5537788", "0355-4114567"],
  whatsapp: ["0344-5537788", "0355-4114567"],
  email: "oasisresort@gmail.com",
  address: "Cold desert, Katpana, Skardu 16100, Gilgit-Baltistan, Pakistan",
  mapQuery: "Oasis Resort Katpana Skardu",
  social: [
    { label: "Facebook", href: "https://facebook.com" },
    { label: "Instagram", href: "https://instagram.com" },
    { label: "YouTube", href: "https://youtube.com" },
  ],
};

export const roomTypes = [
  { slug: "deluxe", name: "Deluxe Room", tagline: "Warm, bright and mountain-facing", image: images.deluxe, count: 9 },
  { slug: "executive", name: "Executive Room", tagline: "More space, more view", image: images.executive, count: 6 },
  { slug: "premium", name: "Premium Cottage", tagline: "Our finest glass-front cottage", image: images.snow, count: 6 },
];

export const gallery = [images.hero, images.snow, images.night, images.deluxe, images.deluxe1, images.deluxe2, images.executive, images.breakfast];
