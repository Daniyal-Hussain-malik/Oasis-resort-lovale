export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      addons: {
        Row: {
          active: boolean
          description: string
          id: string
          name: string
          price: number
          unit: string
        }
        Insert: {
          active?: boolean
          description?: string
          id?: string
          name: string
          price: number
          unit?: string
        }
        Update: {
          active?: boolean
          description?: string
          id?: string
          name?: string
          price?: number
          unit?: string
        }
        Relationships: []
      }
      audit_log: {
        Row: {
          action: string
          actor_id: string | null
          after: Json | null
          before: Json | null
          created_at: string
          id: number
          ip: string | null
          record_id: string | null
          table_name: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          after?: Json | null
          before?: Json | null
          created_at?: string
          id?: never
          ip?: string | null
          record_id?: string | null
          table_name: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          after?: Json | null
          before?: Json | null
          created_at?: string
          id?: never
          ip?: string | null
          record_id?: string | null
          table_name?: string
        }
        Relationships: []
      }
      date_overrides: {
        Row: {
          closed: boolean
          date: string
          id: string
          min_stay: number
          price: number | null
          room_type_id: string
        }
        Insert: {
          closed?: boolean
          date: string
          id?: string
          min_stay?: number
          price?: number | null
          room_type_id: string
        }
        Update: {
          closed?: boolean
          date?: string
          id?: string
          min_stay?: number
          price?: number | null
          room_type_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "date_overrides_room_type_id_fkey"
            columns: ["room_type_id"]
            isOneToOne: false
            referencedRelation: "room_types"
            referencedColumns: ["id"]
          },
        ]
      }
      guest_identity: {
        Row: {
          created_at: string
          id_number_encrypted: string
          id_number_masked: string
          id_type: string
          nationality: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id_number_encrypted: string
          id_number_masked: string
          id_type: string
          nationality?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id_number_encrypted?: string
          id_number_masked?: string
          id_type?: string
          nationality?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      policies: {
        Row: {
          body: string
          id: string
          slug: string
          sort: number
          title: string
          updated_at: string
        }
        Insert: {
          body?: string
          id?: string
          slug: string
          sort?: number
          title: string
          updated_at?: string
        }
        Update: {
          body?: string
          id?: string
          slug?: string
          sort?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          city: string
          country: string
          created_at: string
          full_name: string
          is_active: boolean
          marketing_consent: boolean
          phone: string
          preferences: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          city?: string
          country?: string
          created_at?: string
          full_name?: string
          is_active?: boolean
          marketing_consent?: boolean
          phone?: string
          preferences?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          city?: string
          country?: string
          created_at?: string
          full_name?: string
          is_active?: boolean
          marketing_consent?: boolean
          phone?: string
          preferences?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      rate_plans: {
        Row: {
          active: boolean
          base_price: number
          id: string
          meal_plan: string
          name: string
          refundable: boolean
          room_type_id: string
        }
        Insert: {
          active?: boolean
          base_price: number
          id?: string
          meal_plan?: string
          name: string
          refundable?: boolean
          room_type_id: string
        }
        Update: {
          active?: boolean
          base_price?: number
          id?: string
          meal_plan?: string
          name?: string
          refundable?: boolean
          room_type_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "rate_plans_room_type_id_fkey"
            columns: ["room_type_id"]
            isOneToOne: false
            referencedRelation: "room_types"
            referencedColumns: ["id"]
          },
        ]
      }
      rates: {
        Row: {
          id: string
          price: number
          rate_plan_id: string
          season_id: string
        }
        Insert: {
          id?: string
          price: number
          rate_plan_id: string
          season_id: string
        }
        Update: {
          id?: string
          price?: number
          rate_plan_id?: string
          season_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "rates_rate_plan_id_fkey"
            columns: ["rate_plan_id"]
            isOneToOne: false
            referencedRelation: "rate_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rates_season_id_fkey"
            columns: ["season_id"]
            isOneToOne: false
            referencedRelation: "seasons"
            referencedColumns: ["id"]
          },
        ]
      }
      room_types: {
        Row: {
          active: boolean
          amenities: string[]
          bed: string
          created_at: string
          description: string
          id: string
          images: string[]
          max_adults: number
          max_children: number
          name: string
          size_sqft: number | null
          slug: string
          sort: number
          tagline: string
        }
        Insert: {
          active?: boolean
          amenities?: string[]
          bed?: string
          created_at?: string
          description?: string
          id?: string
          images?: string[]
          max_adults?: number
          max_children?: number
          name: string
          size_sqft?: number | null
          slug: string
          sort?: number
          tagline?: string
        }
        Update: {
          active?: boolean
          amenities?: string[]
          bed?: string
          created_at?: string
          description?: string
          id?: string
          images?: string[]
          max_adults?: number
          max_children?: number
          name?: string
          size_sqft?: number | null
          slug?: string
          sort?: number
          tagline?: string
        }
        Relationships: []
      }
      rooms: {
        Row: {
          active: boolean
          floor: string
          id: string
          number: string
          room_type_id: string
          status: string
        }
        Insert: {
          active?: boolean
          floor?: string
          id?: string
          number: string
          room_type_id: string
          status?: string
        }
        Update: {
          active?: boolean
          floor?: string
          id?: string
          number?: string
          room_type_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "rooms_room_type_id_fkey"
            columns: ["room_type_id"]
            isOneToOne: false
            referencedRelation: "room_types"
            referencedColumns: ["id"]
          },
        ]
      }
      seasons: {
        Row: {
          end_date: string
          id: string
          multiplier: number
          name: string
          start_date: string
        }
        Insert: {
          end_date: string
          id?: string
          multiplier?: number
          name: string
          start_date: string
        }
        Update: {
          end_date?: string
          id?: string
          multiplier?: number
          name?: string
          start_date?: string
        }
        Relationships: []
      }
      settings: {
        Row: {
          is_public: boolean
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          is_public?: boolean
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          is_public?: boolean
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      staff_activity: {
        Row: {
          last_seen: string
          session_id: string
          user_id: string
        }
        Insert: {
          last_seen?: string
          session_id: string
          user_id: string
        }
        Update: {
          last_seen?: string
          session_id?: string
          user_id?: string
        }
        Relationships: []
      }
      taxes: {
        Row: {
          active: boolean
          id: string
          inclusive: boolean
          name: string
          percent: number
        }
        Insert: {
          active?: boolean
          id?: string
          inclusive?: boolean
          name: string
          percent: number
        }
        Update: {
          active?: boolean
          id?: string
          inclusive?: boolean
          name?: string
          percent?: number
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_active_user: { Args: { _user_id: string }; Returns: boolean }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      is_mgr: { Args: { _user_id: string }; Returns: boolean }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
      my_roles: {
        Args: never
        Returns: Database["public"]["Enums"]["app_role"][]
      }
      request_ip: { Args: never; Returns: string }
      staff_heartbeat: { Args: never; Returns: boolean }
      write_audit: {
        Args: {
          _action: string
          _after: Json
          _before: Json
          _record: string
          _table: string
        }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "guest" | "receptionist" | "manager" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["guest", "receptionist", "manager", "admin"],
    },
  },
} as const
