import { cva, type VariantProps } from "class-variance-authority";
import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const tone = cva("inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold", {
  variants: {
    tone: {
      neutral: "bg-muted text-foreground",
      info: "bg-glacier-soft text-navy",
      success: "bg-success/15 text-success",
      warning: "bg-warning/25 text-warning-foreground",
      error: "bg-destructive/15 text-destructive",
      accent: "bg-apricot/20 text-apricot-foreground",
    },
  },
  defaultVariants: { tone: "neutral" },
});

export function StatusBadge({ tone: tn, className, ...p }: HTMLAttributes<HTMLSpanElement> & VariantProps<typeof tone>) {
  return <span className={cn(tone({ tone: tn }), className)} {...p} />;
}
