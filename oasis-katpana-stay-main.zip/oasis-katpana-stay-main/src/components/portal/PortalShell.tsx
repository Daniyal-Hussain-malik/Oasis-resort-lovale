import { useEffect, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import {
  BarChart3, BedDouble, CalendarCheck, CreditCard, FileText, Globe, LayoutDashboard, LogOut, MessageSquare, Moon, ScrollText, Settings, Sun, User, Users,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger,
} from "@/components/ui/sidebar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { t } from "@/i18n";

const staffItems = [
  { label: "portal.dashboard", icon: LayoutDashboard },
  { label: "portal.bookings", icon: CalendarCheck },
  { label: "portal.payments", icon: CreditCard },
  { label: "portal.rooms", icon: BedDouble },
  { label: "portal.guests", icon: Users },
  { label: "portal.enquiries", icon: MessageSquare },
  { label: "portal.reports", icon: BarChart3 },
];
const adminItems = [
  ...staffItems,
  { label: "portal.content", icon: FileText },
  { label: "portal.staff", icon: Users },
  { label: "portal.settings", icon: Settings },
  { label: "portal.audit", icon: ScrollText },
];

export function PortalShell({ kind, children }: { kind: "staff" | "admin"; children: ReactNode }) {
  const items = kind === "admin" ? adminItems : staffItems;
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(localStorage.getItem("oasis-portal-theme") === "dark"); }, []);
  const toggle = () => { const d = !dark; setDark(d); localStorage.setItem("oasis-portal-theme", d ? "dark" : "light"); };

  return (
    <div className={dark ? "dark" : ""}>
      <SidebarProvider>
        <div className="flex min-h-screen w-full bg-background text-foreground">
          <Sidebar collapsible="icon">
            <SidebarHeader>
              <Link to={kind === "admin" ? "/admin" : "/staff"} className="flex min-h-11 items-center gap-2 px-2 font-serif text-xl font-semibold">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-sidebar-primary text-sm text-sidebar-primary-foreground">O</span>
                <span className="truncate group-data-[collapsible=icon]:hidden">{t(kind === "admin" ? "portal.adminTitle" : "portal.staffTitle")}</span>
              </Link>
            </SidebarHeader>
            <SidebarContent>
              <SidebarGroup>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {items.map((it, i) => (
                      <SidebarMenuItem key={it.label}>
                        <SidebarMenuButton isActive={i === 0} tooltip={t(it.label)} className="min-h-11">
                          <it.icon /> <span>{t(it.label)}</span>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>
          </Sidebar>
          <SidebarInset className="min-w-0 bg-background">
            <header className="sticky top-0 z-10 grid h-16 grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-border bg-background/95 px-3 backdrop-blur md:px-6">
              <div className="flex min-w-0 items-center gap-2">
                <SidebarTrigger className="h-11 w-11" />
                <h1 className="truncate font-sans text-lg font-semibold">{t("portal.dashboard")}</h1>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" onClick={toggle} aria-label={t("portal.theme")}>{dark ? <Sun /> : <Moon />}</Button>
                <DropdownMenu>
                  <DropdownMenuTrigger className="grid h-11 w-11 place-items-center rounded-full bg-muted" aria-label="User menu"><User className="h-5 w-5" /></DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem className="min-h-11"><User />{t("portal.profile")}</DropdownMenuItem>
                    <DropdownMenuItem asChild className="min-h-11"><Link to="/"><Globe />{t("portal.viewSite")}</Link></DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="min-h-11"><LogOut />{t("portal.signOut")}</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </header>
            <main className="p-4 md:p-6">{children}</main>
          </SidebarInset>
        </div>
      </SidebarProvider>
    </div>
  );
}

export function PortalPlaceholder() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {["Arrivals today", "Departures today", "Payments to verify", "Rooms free tonight"].map((l) => (
        <div key={l} className="rounded-xl border border-border bg-card p-5">
          <p className="text-sm text-muted-foreground">{l}</p>
          <p className="mt-2 text-3xl font-semibold">—</p>
        </div>
      ))}
      <p className="text-muted-foreground sm:col-span-2 xl:col-span-4">{t("portal.placeholder")}</p>
    </div>
  );
}
