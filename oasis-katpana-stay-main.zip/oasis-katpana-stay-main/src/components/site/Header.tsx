import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ChevronDown, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { t } from "@/i18n";
import { cn } from "@/lib/utils";
import { contact } from "@/content/site";
import { telLink } from "@/lib/format";
import { mainNav, primaryCount } from "./nav";

export function Logo({ light }: { light?: boolean }) {
  return (
    <Link to="/" className="flex min-h-11 shrink-0 items-center gap-2.5" aria-label="Oasis Resort home">
      <svg viewBox="0 0 40 40" className={cn("h-9 w-9", light ? "text-navy-foreground" : "text-navy")} aria-hidden>
        <path d="M4 32 L15 14 L21 23 L26 17 L36 32 Z" fill="currentColor" opacity=".9" />
        <circle cx="29" cy="9" r="3.2" className="fill-apricot" />
      </svg>
      <span className="leading-none">
        <span className={cn("block font-serif text-2xl font-semibold", light ? "text-navy-foreground" : "text-navy")}>{t("brand.name")}</span>
        <span className={cn("eyebrow block text-[0.62rem]", light ? "text-navy-foreground/75" : "text-muted-foreground")}>{t("brand.place")}</span>
      </span>
    </Link>
  );
}

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  const solid = scrolled || open;
  const primary = mainNav.slice(0, primaryCount);
  const more = mainNav.slice(primaryCount);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-[background-color,box-shadow] duration-300",
        solid ? "bg-background/95 shadow-soft backdrop-blur" : "bg-gradient-to-b from-navy/60 to-transparent",
      )}
    >
      <div className="container-site grid h-[4.5rem] grid-cols-[minmax(0,1fr)_auto] items-center gap-4 lg:flex lg:justify-between">
        <Logo light={!solid} />

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {primary.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.to === "/" }}
              className={cn(
                "rounded-full px-3 py-2.5 text-[0.95rem] font-medium transition-colors",
                solid ? "text-foreground hover:bg-accent" : "text-navy-foreground hover:bg-navy-foreground/10",
              )}
              activeProps={{ className: "underline decoration-apricot decoration-2 underline-offset-8" }}
            >
              {t(`nav.${item.key}`)}
            </Link>
          ))}
          <DropdownMenu>
            <DropdownMenuTrigger
              className={cn(
                "inline-flex min-h-11 items-center gap-1 rounded-full px-3 text-[0.95rem] font-medium",
                solid ? "text-foreground hover:bg-accent" : "text-navy-foreground hover:bg-navy-foreground/10",
              )}
            >
              More <ChevronDown className="h-4 w-4" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="min-w-48">
              {more.map((item) => (
                <DropdownMenuItem key={item.to} asChild className="min-h-11">
                  <Link to={item.to}>{t(`nav.${item.key}`)}</Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild variant={solid ? "ghost" : "light"} className="hidden md:inline-flex">
            <Link to="/login">{t("nav.login")}</Link>
          </Button>
          <Button asChild variant="primary" className="hidden sm:inline-flex">
            <Link to="/book">{t("nav.bookNow")}</Link>
          </Button>
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? t("nav.close") : t("nav.menu")}
            className={cn("relative grid h-11 w-11 place-items-center rounded-full lg:hidden", solid ? "text-navy" : "text-navy-foreground")}
          >
            <span className="sr-only">{t("nav.menu")}</span>
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="absolute h-0.5 w-6 rounded bg-current"
                animate={
                  open
                    ? i === 1 ? { opacity: 0 } : { y: 0, rotate: i === 0 ? 45 : -45 }
                    : { y: (i - 1) * 7, rotate: 0, opacity: 1 }
                }
                transition={{ duration: reduce ? 0 : 0.25 }}
              />
            ))}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            className="fixed inset-x-0 bottom-0 top-[4.5rem] z-40 overflow-y-auto bg-background lg:hidden"
            initial={reduce ? { opacity: 0 } : { x: "100%" }}
            animate={reduce ? { opacity: 1 } : { x: 0 }}
            exit={reduce ? { opacity: 0 } : { x: "100%" }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            <nav className="container-site flex flex-col py-6" aria-label="Mobile">
              {mainNav.map((item, i) => (
                <motion.div
                  key={item.to}
                  initial={reduce ? false : { opacity: 0, x: 24 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 + i * 0.03 }}
                >
                  <Link
                    to={item.to}
                    onClick={() => setOpen(false)}
                    className="flex min-h-12 items-center border-b border-border font-serif text-2xl text-navy"
                    activeOptions={{ exact: item.to === "/" }}
                    activeProps={{ className: "text-apricot" }}
                  >
                    {t(`nav.${item.key}`)}
                  </Link>
                </motion.div>
              ))}
              <div className="mt-8 grid gap-3 pb-24">
                <Button asChild variant="primary" size="lg"><Link to="/book" onClick={() => setOpen(false)}>{t("nav.bookNow")}</Link></Button>
                <Button asChild variant="outline" size="lg"><Link to="/login" onClick={() => setOpen(false)}>{t("nav.login")}</Link></Button>
                <a href={telLink(contact.primaryPhone)} className="flex min-h-11 items-center justify-center gap-2 text-muted-foreground">
                  <Phone className="h-4 w-4" /> {contact.primaryPhone}
                </a>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
