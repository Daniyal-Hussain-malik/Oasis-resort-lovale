import { Link } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { SlideUp } from "@/components/motion";
import { t } from "@/i18n";
import { contact } from "@/content/site";
import { whatsappLink } from "@/lib/format";
import { PageHero, type Crumb } from "./PageHero";

export function PlaceholderPage({ title, subtitle, image, crumbs }: { title: string; subtitle?: string | undefined; image?: string | undefined; crumbs?: Crumb[] | undefined }) {
  return (
    <>
      <PageHero title={title} subtitle={subtitle} image={image} crumbs={crumbs ?? [{ label: title }]} />
      <section className="container-site section-y">
        <SlideUp>
          <Card className="mx-auto max-w-2xl rounded-3xl border-border p-8 text-center shadow-soft md:p-12">
            <h2 className="text-3xl">{title}</h2>
            <p className="mt-3 text-muted-foreground">{t("common.comingSoon")}</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Button asChild variant="primary"><Link to="/book">{t("nav.bookNow")}</Link></Button>
              <Button asChild variant="outline">
                <a href={whatsappLink(contact.primaryWhatsapp, t("whatsappMessage"))} target="_blank" rel="noreferrer"><MessageCircle />{t("common.whatsapp")}</a>
              </Button>
            </div>
          </Card>
        </SlideUp>
      </section>
    </>
  );
}
