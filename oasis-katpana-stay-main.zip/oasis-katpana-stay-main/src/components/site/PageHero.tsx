import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { SlideUp } from "@/components/motion";
import { images } from "@/content/site";
import { t } from "@/i18n";

export type Crumb = { label: string; to?: string };

export function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <nav aria-label="Breadcrumb">
      <ol className="flex flex-wrap items-center gap-1 text-sm text-navy-foreground/80">
        <li><Link to="/" className="inline-flex min-h-11 items-center hover:text-apricot">{t("nav.home")}</Link></li>
        {items.map((c) => (
          <li key={c.label} className="flex items-center gap-1">
            <ChevronRight className="h-4 w-4" aria-hidden />
            {c.to ? <Link to={c.to} className="inline-flex min-h-11 items-center hover:text-apricot">{c.label}</Link> : <span aria-current="page">{c.label}</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function PageHero({ title, subtitle, eyebrow, image = images.hero, crumbs, children }: {
  title: string; subtitle?: string | undefined; eyebrow?: string | undefined; image?: string | undefined; crumbs: Crumb[]; children?: ReactNode;
}) {
  return (
    <section className="relative isolate overflow-hidden bg-navy text-navy-foreground">
      <img src={image} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover opacity-45" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-t from-navy via-navy/60 to-navy/30" />
      <div className="container-site pt-32 pb-14 md:pt-40 md:pb-20">
        <Breadcrumbs items={crumbs} />
        <SlideUp>
          {eyebrow && <p className="eyebrow mt-4 text-apricot">{eyebrow}</p>}
          <h1 className="mt-3 max-w-3xl text-4xl sm:text-5xl md:text-6xl">{title}</h1>
          {subtitle && <p className="mt-4 max-w-2xl text-lg text-navy-foreground/85">{subtitle}</p>}
          {children}
        </SlideUp>
      </div>
    </section>
  );
}
