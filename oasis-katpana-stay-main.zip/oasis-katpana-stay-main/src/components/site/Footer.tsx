import { useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Mail, MapPin, MessageCircle, Phone, Youtube, Landmark } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { t } from "@/i18n";
import { contact } from "@/content/site";
import { telLink, whatsappLink } from "@/lib/format";
import { Logo } from "./Header";
import { mainNav } from "./nav";

const icons: Record<string, typeof Facebook> = { Facebook, Instagram, YouTube: Youtube };

export function Footer() {
  const [email, setEmail] = useState("");
  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const r = z.string().trim().email().max(255).safeParse(email);
    if (!r.success) { toast.error("Please enter a valid email address."); return; }
    // Newsletter storage is added with the database step.
    toast.success(t("footer.subscribed"));
    setEmail("");
  };

  return (
    <footer className="bg-navy text-navy-foreground">
      <div className="container-site grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-4">
          <Logo light />
          <p className="max-w-xs text-navy-foreground/75">{t("footer.tagline")}</p>
          <div className="flex gap-2" aria-label={t("footer.follow")}>
            {contact.social.map((s) => {
              const Icon = icons[s.label] ?? Facebook;
              return (
                <a key={s.label} href={s.href} target="_blank" rel="noreferrer" aria-label={s.label}
                  className="grid h-11 w-11 place-items-center rounded-full border border-navy-foreground/20 transition-colors hover:bg-navy-foreground/10">
                  <Icon className="h-5 w-5" />
                </a>
              );
            })}
          </div>
        </div>

        <div>
          <h3 className="mb-4 text-xl">{t("footer.quickLinks")}</h3>
          <ul className="grid grid-cols-2 gap-x-4">
            {[...mainNav.slice(1), { to: "/offers", key: "offers" }, { to: "/reviews", key: "reviews" }, { to: "/events", key: "events" }].map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="flex min-h-11 items-center text-navy-foreground/80 hover:text-apricot">{t(`nav.${l.key}`)}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="mb-4 text-xl">{t("footer.contact")}</h3>
          <ul className="space-y-1 text-navy-foreground/85">
            <li className="flex gap-3 py-2"><MapPin className="mt-1 h-5 w-5 shrink-0 text-apricot" />{contact.address}</li>
            {contact.phones.map((p) => (
              <li key={p}><a href={telLink(p)} className="flex min-h-11 items-center gap-3 hover:text-apricot"><Phone className="h-5 w-5 shrink-0 text-apricot" />{p}</a></li>
            ))}
            <li><a href={whatsappLink(contact.primaryWhatsapp, t("whatsappMessage"))} target="_blank" rel="noreferrer" className="flex min-h-11 items-center gap-3 hover:text-apricot"><MessageCircle className="h-5 w-5 shrink-0 text-apricot" />{contact.whatsapp.join(" / ")}</a></li>
            <li><a href={`mailto:${contact.email}`} className="flex min-h-11 items-center gap-3 break-all hover:text-apricot"><Mail className="h-5 w-5 shrink-0 text-apricot" />{contact.email}</a></li>
          </ul>
        </div>

        <div>
          <h3 className="mb-2 text-xl">{t("footer.newsletter")}</h3>
          <p className="mb-4 text-navy-foreground/75">{t("footer.newsletterText")}</p>
          <form onSubmit={onSubmit} className="flex flex-col gap-2 sm:flex-row lg:flex-col xl:flex-row">
            <label htmlFor="nl-email" className="sr-only">{t("footer.emailPlaceholder")}</label>
            <Input id="nl-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("footer.emailPlaceholder")}
              className="min-h-11 border-navy-foreground/25 bg-navy-foreground/5 text-base text-navy-foreground placeholder:text-navy-foreground/50" />
            <Button type="submit" variant="primary">{t("footer.subscribe")}</Button>
          </form>
          <p className="eyebrow mt-8 mb-3 text-navy-foreground/60">{t("footer.weAccept")}</p>
          <div className="flex flex-wrap gap-2">
            <span className="inline-flex min-h-10 items-center rounded-md bg-success px-3 text-sm font-bold text-success-foreground">easypaisa</span>
            <span className="inline-flex min-h-10 items-center gap-2 rounded-md bg-navy-foreground px-3 text-sm font-semibold text-navy"><Landmark className="h-4 w-4" />{t("footer.bankTransfer")}</span>
          </div>
        </div>
      </div>
      <div className="border-t border-navy-foreground/15">
        <div className="container-site flex flex-col gap-2 py-6 text-sm text-navy-foreground/65 md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} Oasis Resort Skardu. {t("footer.rights")}</p>
          <div className="flex flex-wrap gap-x-5">
            <Link to="/privacy" className="flex min-h-11 items-center hover:text-apricot">{t("footer.privacy")}</Link>
            <Link to="/terms" className="flex min-h-11 items-center hover:text-apricot">{t("footer.terms")}</Link>
            <Link to="/cancellation-policy" className="flex min-h-11 items-center hover:text-apricot">{t("footer.cancellation")}</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
