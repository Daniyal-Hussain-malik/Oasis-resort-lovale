export const mainNav = [
  { to: "/", key: "home" },
  { to: "/about", key: "about" },
  { to: "/stay", key: "stay" },
  { to: "/facilities", key: "facilities" },
  { to: "/experiences", key: "experiences" },
  { to: "/activities", key: "activities" },
  { to: "/gallery", key: "gallery" },
  { to: "/blog", key: "blog" },
  { to: "/faq", key: "faq" },
  { to: "/directions", key: "directions" },
  { to: "/virtual-tour", key: "virtualTour" },
  { to: "/contact", key: "contact" },
] as const;

/** Shown directly in the desktop header; the rest go under "More". */
export const primaryCount = 6;
