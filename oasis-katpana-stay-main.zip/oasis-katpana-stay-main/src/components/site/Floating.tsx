import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { t } from "@/i18n";
import { contact } from "@/content/site";
import { whatsappLink } from "@/lib/format";

const wa = () => whatsappLink(contact.primaryWhatsapp, t("whatsappMessage"));

export function WhatsAppFab() {
  return (
    <a
      href={wa()}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat with us on WhatsApp"
      className="fixed bottom-6 right-6 z-40 hidden h-14 w-14 place-items-center rounded-full bg-whatsapp text-navy-foreground shadow-lift transition-transform hover:-translate-y-1 lg:grid"
    >
      <MessageCircle className="h-7 w-7" />
    </a>
  );
}

export function MobileBookBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-2 gap-2 border-t border-border bg-background/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur lg:hidden">
      <Button asChild variant="primary" size="lg"><Link to="/book">{t("nav.bookNow")}</Link></Button>
      <Button asChild size="lg" className="bg-whatsapp text-navy-foreground hover:bg-whatsapp/90">
        <a href={wa()} target="_blank" rel="noreferrer"><MessageCircle />{t("common.whatsapp")}</a>
      </Button>
    </div>
  );
}

const KEY = "oasis-cookie-consent";

export function CookieBanner() {
  const [show, setShow] = useState(false);
  useEffect(() => { setShow(!localStorage.getItem(KEY)); }, []);
  const choose = (v: string) => { localStorage.setItem(KEY, v); setShow(false); };
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          role="dialog"
          aria-label="Cookie consent"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 24 }}
          className="fixed inset-x-3 bottom-24 z-50 mx-auto max-w-xl rounded-2xl border border-border bg-card p-5 shadow-lift lg:bottom-6 lg:left-6 lg:right-auto"
        >
          <p className="text-[0.95rem]">{t("cookie.text")} <Link to="/privacy" className="underline">{t("cookie.more")}</Link></p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => choose("all")}>{t("cookie.accept")}</Button>
            <Button variant="ghost" onClick={() => choose("essential")}>{t("cookie.decline")}</Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
