import type { ReactNode } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHero } from "./PageHero";
import { images } from "@/content/site";

export function Field({ id, label, type = "text", autoComplete }: { id: string; label: string; type?: string; autoComplete?: string }) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={id} className="text-[0.95rem]">{label}</Label>
      <Input id={id} name={id} type={type} autoComplete={autoComplete} className="min-h-12 rounded-xl bg-card text-base" />
    </div>
  );
}

export function AuthCard({ title, subtitle, children }: { title: string; subtitle: string; children: ReactNode }) {
  return (
    <>
      <PageHero title={title} subtitle={subtitle} image={images.snow} crumbs={[{ label: title }]} />
      <section className="container-site section-y">
        <Card className="mx-auto max-w-md rounded-3xl p-6 shadow-soft md:p-8">{children}</Card>
      </section>
    </>
  );
}
