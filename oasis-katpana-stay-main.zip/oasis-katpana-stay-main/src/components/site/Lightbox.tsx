import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { HoverLift } from "@/components/motion";

export function Lightbox({ images, open, index, onClose, onIndex }: { images: string[]; open: boolean; index: number; onClose: () => void; onIndex: (i: number) => void }) {
  const go = useCallback((d: number) => onIndex((index + d + images.length) % images.length), [index, images.length, onIndex]);
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => { if (e.key === "ArrowRight") go(1); if (e.key === "ArrowLeft") go(-1); };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, go]);
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-[min(96vw,80rem)] border-0 bg-navy p-2 [&>button]:hidden">
        <DialogTitle className="sr-only">Photo {index + 1} of {images.length}</DialogTitle>
        <img src={images[index]} alt={`Oasis Resort photo ${index + 1}`} className="max-h-[80vh] w-full rounded-lg object-contain" />
        <div className="flex items-center justify-between p-1 text-navy-foreground">
          <button aria-label="Previous photo" onClick={() => go(-1)} className="grid h-11 w-11 place-items-center rounded-full hover:bg-navy-foreground/10"><ChevronLeft /></button>
          <span className="text-sm">{index + 1} / {images.length}</span>
          <div className="flex">
            <button aria-label="Next photo" onClick={() => go(1)} className="grid h-11 w-11 place-items-center rounded-full hover:bg-navy-foreground/10"><ChevronRight /></button>
            <button aria-label="Close" onClick={onClose} className="grid h-11 w-11 place-items-center rounded-full hover:bg-navy-foreground/10"><X /></button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function GalleryGrid({ images }: { images: string[] }) {
  const [i, setI] = useState(-1);
  return (
    <>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
        {images.map((src, n) => (
          <HoverLift key={src} className={n % 5 === 0 ? "col-span-2 row-span-2" : ""}>
            <button onClick={() => setI(n)} className="block h-full w-full overflow-hidden rounded-2xl" aria-label={`Open photo ${n + 1}`}>
              <img src={src} alt="" loading="lazy" className="aspect-square h-full w-full object-cover transition-transform duration-700 hover:scale-105" />
            </button>
          </HoverLift>
        ))}
      </div>
      <Lightbox images={images} open={i >= 0} index={Math.max(i, 0)} onClose={() => setI(-1)} onIndex={setI} />
    </>
  );
}
