import { useState } from "react";
import type { DateRange } from "react-day-picker";
import { CalendarDays } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useIsMobile } from "@/hooks/use-mobile";
import { formatDate } from "@/lib/format";
import { t } from "@/i18n";
import { cn } from "@/lib/utils";

export function DateRangePicker({ value, onChange, className }: { value?: DateRange | undefined; onChange: (r: DateRange | undefined) => void; className?: string | undefined }) {
  const [open, setOpen] = useState(false);
  const mobile = useIsMobile();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const nights = value?.from && value?.to ? Math.round((value.to.getTime() - value.from.getTime()) / 86400000) : 0;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger
        className={cn("flex min-h-12 w-full items-center gap-3 rounded-xl border border-input bg-card px-4 text-left text-base", className)}
      >
        <CalendarDays className="h-5 w-5 shrink-0 text-glacier" />
        <span className="min-w-0 truncate">
          {value?.from ? (
            <>
              {formatDate(value.from)} – {value.to ? formatDate(value.to) : "…"}
              {nights > 0 && <span className="text-muted-foreground"> · {nights} {nights === 1 ? t("common.night") : t("common.nights")}</span>}
            </>
          ) : (
            <span className="text-muted-foreground">{t("common.selectDates")}</span>
          )}
        </span>
      </PopoverTrigger>
      <PopoverContent className="w-auto max-w-[calc(100vw-1.5rem)] p-0" align="start">
        <Calendar
          mode="range"
          numberOfMonths={mobile ? 1 : 2}
          selected={value}
          onSelect={(r) => { onChange(r); if (r?.from && r?.to && r.from.getTime() !== r.to.getTime()) setOpen(false); }}
          disabled={{ before: today }}
          defaultMonth={value?.from ?? today}
        />
      </PopoverContent>
    </Popover>
  );
}
