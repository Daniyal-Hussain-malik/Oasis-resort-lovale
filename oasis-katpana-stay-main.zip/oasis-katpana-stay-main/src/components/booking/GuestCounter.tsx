import { Minus, Plus, Users } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { t } from "@/i18n";
import { cn } from "@/lib/utils";

export type Guests = { adults: number; children: number };

function Row({ label, hint, value, min, max, onChange }: { label: string; hint: string; value: number; min: number; max: number; onChange: (v: number) => void }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <div className="min-w-0">
        <p className="font-semibold">{label}</p>
        <p className="text-sm text-muted-foreground">{hint}</p>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        <button type="button" aria-label={`Fewer ${label}`} disabled={value <= min} onClick={() => onChange(value - 1)}
          className="grid h-11 w-11 place-items-center rounded-full border border-input disabled:opacity-40"><Minus className="h-4 w-4" /></button>
        <span className="w-6 text-center text-lg font-semibold" aria-live="polite">{value}</span>
        <button type="button" aria-label={`More ${label}`} disabled={value >= max} onClick={() => onChange(value + 1)}
          className="grid h-11 w-11 place-items-center rounded-full border border-input disabled:opacity-40"><Plus className="h-4 w-4" /></button>
      </div>
    </div>
  );
}

export function GuestCounter({ value, onChange, maxAdults = 12, maxChildren = 8, className }: { value: Guests; onChange: (g: Guests) => void; maxAdults?: number; maxChildren?: number; className?: string }) {
  return (
    <Popover>
      <PopoverTrigger className={cn("flex min-h-12 w-full items-center gap-3 rounded-xl border border-input bg-card px-4 text-left text-base", className)}>
        <Users className="h-5 w-5 shrink-0 text-glacier" />
        <span className="truncate">{value.adults} {t("common.adults").toLowerCase()}{value.children ? `, ${value.children} ${t("common.children").toLowerCase()}` : ""}</span>
      </PopoverTrigger>
      <PopoverContent className="w-80 max-w-[calc(100vw-1.5rem)]" align="start">
        <Row label={t("common.adults")} hint={t("common.age13")} value={value.adults} min={1} max={maxAdults} onChange={(adults) => onChange({ ...value, adults })} />
        <Row label={t("common.children")} hint={t("common.ages")} value={value.children} min={0} max={maxChildren} onChange={(children) => onChange({ ...value, children })} />
      </PopoverContent>
    </Popover>
  );
}
