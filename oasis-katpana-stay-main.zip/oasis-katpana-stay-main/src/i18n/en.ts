// All UI text lives here so an Urdu file (ur.ts) can be added later with the same keys.
export const en = {
  brand: { name: "Oasis Resort", place: "Katpana · Skardu" },
  nav: {
    home: "Home", about: "About", stay: "Stay", facilities: "Facilities", experiences: "Experiences",
    activities: "Activities", gallery: "Gallery", blog: "Blog", faq: "FAQ", directions: "Directions",
    virtualTour: "Virtual Tour", contact: "Contact", offers: "Offers", reviews: "Reviews", events: "Events",
    login: "Login", register: "Register", bookNow: "Book Now", account: "My account", menu: "Menu", close: "Close",
  },
  common: {
    whatsapp: "WhatsApp", call: "Call", email: "Email", learnMore: "Learn more", backHome: "Back to home",
    comingSoon: "This page is being prepared. Check back soon, or message us on WhatsApp for anything you need.",
    adults: "Adults", children: "Children", ages: "Ages 2–12", age13: "Age 13+", checkIn: "Check-in", checkOut: "Check-out",
    selectDates: "Select dates", guests: "Guests", nights: "nights", night: "night",
  },
  footer: {
    tagline: "Glass-fronted cottages in the Katpana cold desert, facing the Karakoram.",
    quickLinks: "Quick links", contact: "Contact", newsletter: "Newsletter",
    newsletterText: "Seasonal offers and travel tips for Skardu. No spam.",
    emailPlaceholder: "Your email", subscribe: "Subscribe", subscribed: "Thanks! You're on the list.",
    weAccept: "We accept", bankTransfer: "Bank transfer", privacy: "Privacy", terms: "Terms",
    cancellation: "Cancellation policy", rights: "All rights reserved.", follow: "Follow us",
  },
  whatsappMessage: "Assalam-o-Alaikum, I want to ask about a stay at Oasis Resort",
  cookie: {
    text: "We use essential cookies to keep the site working and optional ones to understand how it's used.",
    accept: "Accept", decline: "Only essential", more: "Privacy policy",
  },
  errors: {
    notFoundTitle: "Lost in the desert",
    notFoundBody: "We couldn't find that page. The dunes shift, but your stay is still waiting.",
    errorTitle: "Something went wrong",
    errorBody: "This page didn't load. Please try again, or head home.",
    tryAgain: "Try again",
  },
  portal: {
    staffTitle: "Staff portal", adminTitle: "Admin portal", dashboard: "Dashboard", bookings: "Bookings",
    payments: "Payments", rooms: "Rooms", guests: "Guests", enquiries: "Enquiries", reports: "Reports",
    content: "Website content", staff: "Staff & roles", settings: "Settings", audit: "Audit log",
    signOut: "Sign out", profile: "Profile", theme: "Toggle theme", viewSite: "View website",
    placeholder: "This area will be built in the next step.",
  },
} as const;
