import { en } from "./en";

export type Dict = typeof en;
const dicts: Record<string, Dict> = { en };
let current = "en";

export function setLocale(locale: string) {
  if (dicts[locale]) current = locale;
}

/** Look up UI text by dotted key, e.g. t("nav.bookNow"). */
export function t(key: string): string {
  const parts = key.split(".");
  let node: unknown = dicts[current];
  for (const p of parts) node = (node as Record<string, unknown> | undefined)?.[p];
  return typeof node === "string" ? node : key;
}
