export const TIME_ZONE = "Asia/Karachi";

/** PKR 25,000 */
export function formatPKR(amount: number): string {
  return `PKR ${Math.round(amount).toLocaleString("en-US")}`;
}

/** 19 Oct 2026 (in Asia/Karachi) */
export function formatDate(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric", timeZone: TIME_ZONE }).format(date);
}

/** wa.me link from a local Pakistani number like 0344-5537788 */
export function whatsappLink(number: string, message?: string): string {
  const digits = number.replace(/\D/g, "").replace(/^0/, "92");
  return `https://wa.me/${digits}${message ? `?text=${encodeURIComponent(message)}` : ""}`;
}

export function telLink(number: string): string {
  return `tel:${number.replace(/[^\d+]/g, "")}`;
}
