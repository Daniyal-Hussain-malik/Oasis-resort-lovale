
CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE public.app_role AS ENUM ('guest','receptionist','manager','admin');

CREATE TABLE public.profiles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  country text NOT NULL DEFAULT 'Pakistan',
  city text NOT NULL DEFAULT '',
  preferences jsonb NOT NULL DEFAULT '{}'::jsonb,
  marketing_consent boolean NOT NULL DEFAULT false,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.staff_activity (
  session_id text PRIMARY KEY,
  user_id uuid NOT NULL,
  last_seen timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.staff_activity TO service_role;
ALTER TABLE public.staff_activity ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.is_active_user(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE((SELECT is_active FROM public.profiles WHERE user_id = _user_id), false)
$$;

-- Staff: active staff role AND current session seen within the last 30 minutes.
CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT _user_id IS NOT NULL
    AND _user_id = auth.uid()
    AND public.is_active_user(_user_id)
    AND EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('receptionist','manager','admin'))
    AND EXISTS (SELECT 1 FROM public.staff_activity s
                WHERE s.session_id = (auth.jwt()->>'session_id') AND s.user_id = _user_id
                  AND s.last_seen > now() - interval '30 minutes')
$$;

-- Manager or admin, with two-factor completed.
CREATE OR REPLACE FUNCTION public.is_mgr(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_staff(_user_id)
    AND (public.has_role(_user_id,'manager') OR public.has_role(_user_id,'admin'))
    AND COALESCE(auth.jwt()->>'aal','') = 'aal2'
$$;

CREATE OR REPLACE FUNCTION public.is_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_staff(_user_id) AND public.has_role(_user_id,'admin')
    AND COALESCE(auth.jwt()->>'aal','') = 'aal2'
$$;

-- Heartbeat: returns false if this staff session idled past 30 min (client must sign out).
CREATE OR REPLACE FUNCTION public.staff_heartbeat()
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE sid text := auth.jwt()->>'session_id'; last timestamptz;
BEGIN
  IF auth.uid() IS NULL OR sid IS NULL THEN RETURN false; END IF;
  IF NOT public.is_active_user(auth.uid()) THEN RETURN false; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role IN ('receptionist','manager','admin')) THEN RETURN false; END IF;
  SELECT last_seen INTO last FROM public.staff_activity WHERE session_id = sid;
  IF last IS NOT NULL AND last < now() - interval '30 minutes' THEN RETURN false; END IF;
  INSERT INTO public.staff_activity(session_id, user_id, last_seen) VALUES (sid, auth.uid(), now())
  ON CONFLICT (session_id) DO UPDATE SET last_seen = now();
  RETURN true;
END $$;
REVOKE EXECUTE ON FUNCTION public.staff_heartbeat() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.staff_heartbeat() TO authenticated;

CREATE OR REPLACE FUNCTION public.my_roles()
RETURNS SETOF public.app_role LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM public.user_roles WHERE user_id = auth.uid()
$$;
GRANT EXECUTE ON FUNCTION public.my_roles() TO authenticated;

CREATE POLICY "roles: own or admin read" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_admin(auth.uid()));

CREATE POLICY "profiles: own or staff read" ON public.profiles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_staff(auth.uid()));
CREATE POLICY "profiles: own insert" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND is_active = true);
CREATE POLICY "profiles: own update" ON public.profiles FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "profiles: admin update" ON public.profiles FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

-- Guests cannot change their own is_active flag.
CREATE OR REPLACE FUNCTION public.protect_profile_fields()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.is_active IS DISTINCT FROM OLD.is_active
     AND current_user NOT IN ('service_role','postgres','supabase_admin')
     AND NOT public.is_admin(auth.uid()) THEN
    RAISE EXCEPTION 'Not allowed to change account status';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER profiles_protect BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.protect_profile_fields();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name, phone)
  VALUES (NEW.id,
          COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
          COALESCE(NEW.phone, NEW.raw_user_meta_data->>'phone', ''))
  ON CONFLICT (user_id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'guest') ON CONFLICT DO NOTHING;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Audit log
CREATE TABLE public.audit_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  actor_id uuid,
  action text NOT NULL,
  table_name text NOT NULL,
  record_id text,
  before jsonb,
  after jsonb,
  ip text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_log TO authenticated;
GRANT ALL ON public.audit_log TO service_role;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "audit: admin read" ON public.audit_log FOR SELECT TO authenticated USING (public.is_admin(auth.uid()));

CREATE OR REPLACE FUNCTION public.request_ip()
RETURNS text LANGUAGE sql STABLE AS $$
  SELECT split_part(COALESCE(
    NULLIF(current_setting('request.headers', true), '')::json->>'cf-connecting-ip',
    NULLIF(current_setting('request.headers', true), '')::json->>'x-forwarded-for',
    NULLIF(current_setting('request.headers', true), '')::json->>'x-real-ip'), ',', 1)
$$;

CREATE OR REPLACE FUNCTION public.audit_row_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE uid uuid := auth.uid(); rec jsonb;
BEGIN
  IF uid IS NOT NULL AND EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = uid AND role IN ('receptionist','manager','admin')) THEN
    rec := CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END;
    INSERT INTO public.audit_log(actor_id, action, table_name, record_id, before, after, ip)
    VALUES (uid, lower(TG_OP), TG_TABLE_NAME,
            COALESCE(rec->>'id', rec->>'user_id', rec->>'key'),
            CASE WHEN TG_OP <> 'INSERT' THEN to_jsonb(OLD) END,
            CASE WHEN TG_OP <> 'DELETE' THEN to_jsonb(NEW) END,
            public.request_ip());
  END IF;
  RETURN COALESCE(NEW, OLD);
END $$;

CREATE OR REPLACE FUNCTION public.write_audit(_action text, _table text, _record text, _before jsonb, _after jsonb)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  INSERT INTO public.audit_log(actor_id, action, table_name, record_id, before, after, ip)
  VALUES (auth.uid(), _action, _table, _record, _before, _after, public.request_ip())
$$;
REVOKE EXECUTE ON FUNCTION public.write_audit(text,text,text,jsonb,jsonb) FROM PUBLIC, anon, authenticated;

CREATE TRIGGER audit_profiles AFTER INSERT OR UPDATE OR DELETE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_user_roles AFTER INSERT OR UPDATE OR DELETE ON public.user_roles FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();

-- Settings
CREATE TABLE public.settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  is_public boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.settings TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.settings TO authenticated;
GRANT ALL ON public.settings TO service_role;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings: public keys" ON public.settings FOR SELECT USING (is_public OR public.is_admin(auth.uid()));
CREATE POLICY "settings: admin write" ON public.settings FOR ALL TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE TRIGGER audit_settings AFTER INSERT OR UPDATE OR DELETE ON public.settings FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
