
-- id_number_encrypted holds AES-GCM ciphertext produced by a server function (key is a server secret).
CREATE TABLE public.guest_identity (
  user_id uuid PRIMARY KEY,
  id_type text NOT NULL CHECK (id_type IN ('cnic','passport')),
  id_number_encrypted text NOT NULL,
  id_number_masked text NOT NULL,
  nationality text NOT NULL DEFAULT 'Pakistani',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.guest_identity TO authenticated;
GRANT ALL ON public.guest_identity TO service_role;
ALTER TABLE public.guest_identity ENABLE ROW LEVEL SECURITY;
CREATE POLICY "identity: own or staff read" ON public.guest_identity FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_staff(auth.uid()));
CREATE TRIGGER audit_guest_identity AFTER INSERT OR UPDATE OR DELETE ON public.guest_identity FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();

CREATE TABLE public.room_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  name text NOT NULL,
  tagline text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  max_adults int NOT NULL DEFAULT 2 CHECK (max_adults > 0),
  max_children int NOT NULL DEFAULT 1 CHECK (max_children >= 0),
  size_sqft int,
  bed text NOT NULL DEFAULT '',
  amenities text[] NOT NULL DEFAULT '{}',
  images text[] NOT NULL DEFAULT '{}',
  sort int NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_type_id uuid NOT NULL REFERENCES public.room_types(id) ON DELETE RESTRICT,
  number text UNIQUE NOT NULL,
  floor text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'clean' CHECK (status IN ('clean','dirty','maintenance','out_of_order')),
  active boolean NOT NULL DEFAULT true
);
CREATE TABLE public.rate_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_type_id uuid NOT NULL REFERENCES public.room_types(id) ON DELETE CASCADE,
  name text NOT NULL,
  base_price integer NOT NULL CHECK (base_price >= 0),
  meal_plan text NOT NULL DEFAULT 'room_only',
  refundable boolean NOT NULL DEFAULT true,
  active boolean NOT NULL DEFAULT true
);
CREATE TABLE public.seasons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  multiplier numeric(5,2) NOT NULL DEFAULT 1.00 CHECK (multiplier > 0),
  CHECK (end_date >= start_date)
);
CREATE TABLE public.rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rate_plan_id uuid NOT NULL REFERENCES public.rate_plans(id) ON DELETE CASCADE,
  season_id uuid NOT NULL REFERENCES public.seasons(id) ON DELETE CASCADE,
  price integer NOT NULL CHECK (price >= 0),
  UNIQUE (rate_plan_id, season_id)
);
CREATE TABLE public.date_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_type_id uuid NOT NULL REFERENCES public.room_types(id) ON DELETE CASCADE,
  date date NOT NULL,
  price integer CHECK (price >= 0),
  closed boolean NOT NULL DEFAULT false,
  min_stay int NOT NULL DEFAULT 1 CHECK (min_stay >= 1),
  UNIQUE (room_type_id, date)
);
CREATE TABLE public.taxes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  percent numeric(5,2) NOT NULL CHECK (percent >= 0 AND percent <= 100),
  inclusive boolean NOT NULL DEFAULT true,
  active boolean NOT NULL DEFAULT true
);
CREATE TABLE public.policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  sort int NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.addons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  price integer NOT NULL CHECK (price >= 0),
  unit text NOT NULL DEFAULT 'per_stay' CHECK (unit IN ('per_stay','per_night','per_person','per_person_night')),
  active boolean NOT NULL DEFAULT true
);

GRANT SELECT ON public.room_types, public.rate_plans, public.seasons, public.rates, public.date_overrides, public.taxes, public.policies, public.addons TO anon, authenticated;
GRANT SELECT ON public.rooms TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.room_types, public.rooms, public.rate_plans, public.seasons, public.rates, public.date_overrides, public.taxes, public.policies, public.addons TO authenticated;
GRANT ALL ON public.room_types, public.rooms, public.rate_plans, public.seasons, public.rates, public.date_overrides, public.taxes, public.policies, public.addons TO service_role;

ALTER TABLE public.room_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rate_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seasons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.date_overrides ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.taxes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.addons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "room_types: public read active" ON public.room_types FOR SELECT USING (active OR public.is_staff(auth.uid()));
CREATE POLICY "room_types: mgr write" ON public.room_types FOR ALL TO authenticated USING (public.is_mgr(auth.uid())) WITH CHECK (public.is_mgr(auth.uid()));
CREATE POLICY "rooms: staff read" ON public.rooms FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "rooms: mgr write" ON public.rooms FOR ALL TO authenticated USING (public.is_mgr(auth.uid())) WITH CHECK (public.is_mgr(auth.uid()));
CREATE POLICY "rooms: staff housekeeping update" ON public.rooms FOR UPDATE TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));
CREATE POLICY "rate_plans: public read" ON public.rate_plans FOR SELECT USING (active OR public.is_staff(auth.uid()));
CREATE POLICY "rate_plans: mgr write" ON public.rate_plans FOR ALL TO authenticated USING (public.is_mgr(auth.uid())) WITH CHECK (public.is_mgr(auth.uid()));
CREATE POLICY "seasons: public read" ON public.seasons FOR SELECT USING (true);
CREATE POLICY "seasons: mgr write" ON public.seasons FOR ALL TO authenticated USING (public.is_mgr(auth.uid())) WITH CHECK (public.is_mgr(auth.uid()));
CREATE POLICY "rates: public read" ON public.rates FOR SELECT USING (true);
CREATE POLICY "rates: mgr write" ON public.rates FOR ALL TO authenticated USING (public.is_mgr(auth.uid())) WITH CHECK (public.is_mgr(auth.uid()));
CREATE POLICY "date_overrides: public read" ON public.date_overrides FOR SELECT USING (true);
CREATE POLICY "date_overrides: mgr write" ON public.date_overrides FOR ALL TO authenticated USING (public.is_mgr(auth.uid())) WITH CHECK (public.is_mgr(auth.uid()));
CREATE POLICY "taxes: public read" ON public.taxes FOR SELECT USING (true);
CREATE POLICY "taxes: admin write" ON public.taxes FOR ALL TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "policies: public read" ON public.policies FOR SELECT USING (true);
CREATE POLICY "policies: admin write" ON public.policies FOR ALL TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "addons: public read" ON public.addons FOR SELECT USING (active OR public.is_staff(auth.uid()));
CREATE POLICY "addons: mgr write" ON public.addons FOR ALL TO authenticated USING (public.is_mgr(auth.uid())) WITH CHECK (public.is_mgr(auth.uid()));

CREATE TRIGGER audit_room_types AFTER INSERT OR UPDATE OR DELETE ON public.room_types FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_rooms AFTER INSERT OR UPDATE OR DELETE ON public.rooms FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_rate_plans AFTER INSERT OR UPDATE OR DELETE ON public.rate_plans FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_seasons AFTER INSERT OR UPDATE OR DELETE ON public.seasons FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_rates AFTER INSERT OR UPDATE OR DELETE ON public.rates FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_date_overrides AFTER INSERT OR UPDATE OR DELETE ON public.date_overrides FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_taxes AFTER INSERT OR UPDATE OR DELETE ON public.taxes FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_policies AFTER INSERT OR UPDATE OR DELETE ON public.policies FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
CREATE TRIGGER audit_addons AFTER INSERT OR UPDATE OR DELETE ON public.addons FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
