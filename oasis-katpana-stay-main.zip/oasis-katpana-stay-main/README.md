# Oasis Katpana Stay

PROJECT: Official website and booking system for Oasis Resort, Katpana, Skardu, Gilgit-Baltistan, Pakistan.

GOAL: Get guests to book directly instead of through OTAs (Booking.com, Agoda). Run front-desk work digitally. Give the owner full control without a developer.

USERS AND ROLES (enforce on the server with Row Level Security, not just by hiding buttons):
- Visitor: browses, searches availability, starts a booking.
- Guest: registered user; manages own bookings, payments, profile; can review ONLY after a verified, checked-out stay.
- Receptionist: bookings, check-in/out, room assignment, payment verification, enquiries, daily reports.
- Manager: everything a receptionist does + rates, availability, promotions, review moderation, refunds (up to a limit), operational reports.
- Admin (owner): everything + website content, staff accounts and roles, settings, payment accounts, revenue reports, audit log.

CORE RULES:
- Every piece of website content (text, images, prices, policies, FAQs) must be editable from the Admin portal. Nothing important is hard-coded.
- No double bookings. Availability must be checked and rooms held inside a database transaction.
- A booking is "Confirmed" only after payment is verified (by staff for manual payments).
- Booking statuses: pending_payment, payment_under_review, confirmed, checked_in, checked_out, cancelled, no_show, expired.
- Payments at launch: Easypaisa manual transfer (guest pays to our Easypaisa account and uploads proof) and bank transfer (guest uploads receipt). Online Easypaisa gateway comes later; build the payment code so new methods can be added.
- Reviews: one per booking, only after staff checks the guest out; moderated before publishing; shown with a "Verified stay" badge.
- Every staff create/edit/delete, payment approval and refund is written to an audit log.
- Never store card numbers or wallet PINs. CNIC/passport numbers and uploaded IDs/payment proofs are private: only authorised staff can view them, through signed links.

LOCALE: Currency PKR (format: PKR 25,000). Time zone Asia/Karachi. Dates like 19 Oct 2026. English at launch; keep all UI text in translation files so Urdu can be added later.

DESIGN: Premium mountain-resort feel. Colours inspired by the landscape: desert sand, glacier blue, night-sky navy, apricot accent. Elegant serif for headings, clean sans-serif for body. Large photography, generous white space. Mobile-first; must work perfectly from 320px phones to large desktops. Smooth, calm animations on every section (fade/slide on scroll, hover lifts), but respect prefers-reduced-motion and never slow down booking.

PORTALS: Public site at /, Guest portal at /account, staff portal at /staff, admin portal at /admin. Staff and admin portals prioritise speed and clarity over animation.

CONTACT DETAILS: Phone [PHONE], WhatsApp [WHATSAPP], Email [EMAIL], Address [FULL ADDRESS], Katpana, Skardu. Google Maps coordinates [LAT, LNG].

WORKING STYLE: Only change what the current prompt asks for. Reuse existing components. Ask me questions before building if anything is unclear.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/2113d483-7281-4e71-aab3-5dc996cc5666).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
