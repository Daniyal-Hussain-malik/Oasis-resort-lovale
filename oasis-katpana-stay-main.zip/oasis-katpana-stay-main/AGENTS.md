<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- Public pages live under the pathless `src/routes/_site/` layout (header, footer, floating bars); `/staff` and `/admin` use `PortalShell` so portals stay separate and light/dark capable.
- UI strings go through `t()` from `src/i18n` so another language file can be added without touching components.
- Animations only via `src/components/motion` wrappers (transform/opacity, reduced-motion aware); booking steps and portals stay animation-free for speed.
- `src/content/site.ts` holds starter content only until the admin-editable database store exists.
